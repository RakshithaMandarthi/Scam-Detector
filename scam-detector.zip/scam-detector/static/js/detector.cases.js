/* Test messages for the detector.
 * expect   = verdict the message should get
 * includes = reason keys that must be present in the result
 * Add your own cases here, then open /static/tests.html.
 */
(function (root) {
  'use strict';

  var cases = [
    { name: 'Normal chat message',
      text: 'Hi, are we still meeting for lunch tomorrow?',
      expect: 'safe' },

    { name: 'Real OTP message (do-not-share warning)',
      text: '123456 is your OTP for a transaction of Rs 500. Do not share it with anyone.',
      expect: 'safe' },

    { name: 'E-mail address is not a link',
      text: 'Mail me at john@gmail.com',
      expect: 'safe' },

    { name: 'Official bank link',
      text: 'Your bill is ready: https://www.hdfcbank.com/statement',
      expect: 'safe' },

    { name: 'Offer with free recharge',
      text: 'Limited time offer! Click the link below for a free recharge.',
      expect: 'suspicious',
      includes: ['r.urgency', 'r.freebie', 'r.click'] },

    { name: 'Shortened parcel link',
      text: 'Track your parcel here: bit.ly/3xYz12',
      expect: 'suspicious',
      includes: ['u.short'] },

    { name: 'Raw IP address link',
      text: 'Open http://192.168.10.5/login to update account',
      expect: 'suspicious',
      includes: ['u.http', 'u.ip'] },

    { name: 'Work-from-home job scam',
      text: 'Work from home! Earn per day Rs 5000. Join our Telegram group, no experience needed',
      expect: 'suspicious',
      includes: ['r.job'] },

    { name: 'Asks for OTP to get a refund',
      text: 'Please share your OTP to confirm the refund',
      expect: 'scam',
      includes: ['r.sensitive', 'r.money'] },

    { name: 'Prize scam with fake link',
      text: 'CONGRATULATIONS! You have won a free iPhone. Click http://claim-iphone.top now to claim your prize',
      expect: 'scam',
      includes: ['r.prize', 'u.http', 'u.tld'] },

    { name: 'Fake bank KYC page',
      text: 'Your SBI account is suspended. Verify now: http://sbi-kyc-update.xyz/login',
      expect: 'scam',
      includes: ['r.threat', 'u.lookalike'] },

    { name: 'Hindi prize message',
      text: 'बधाई हो! आपने इनाम जीता है, तुरंत क्लिक करें',
      expect: 'scam',
      includes: ['r.prize', 'r.urgency', 'r.click'] },

    { name: 'Kannada prize message',
      text: 'ನೀವು ಬಹುಮಾನ ಗೆದ್ದಿದ್ದೀರಿ, ತಕ್ಷಣ ಕ್ಲಿಕ್ ಮಾಡಿ',
      expect: 'scam',
      includes: ['r.prize', 'r.urgency', 'r.click'] }
  ];

  if (typeof module !== 'undefined' && module.exports) module.exports = cases;
  else root.DETECTOR_CASES = cases;
})(typeof window !== 'undefined' ? window : globalThis);
